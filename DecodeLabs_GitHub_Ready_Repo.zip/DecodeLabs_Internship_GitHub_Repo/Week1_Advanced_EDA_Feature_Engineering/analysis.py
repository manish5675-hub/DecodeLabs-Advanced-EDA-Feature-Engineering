
import pandas as pd

df = pd.read_excel('data.xlsx')

# Missing value treatment
for col in df.select_dtypes(include='number').columns:
    df[col] = df[col].fillna(df[col].mean())

# IQR Outlier Treatment
for col in df.select_dtypes(include='number').columns:
    q1=df[col].quantile(0.25)
    q3=df[col].quantile(0.75)
    iqr=q3-q1
    lower=q1-1.5*iqr
    upper=q3+1.5*iqr
    df=df[(df[col]>=lower)&(df[col]<=upper)]

# Example feature engineering
num_cols=df.select_dtypes(include='number').columns
if len(num_cols)>=2:
    df['feature_sum']=df[num_cols[0]]+df[num_cols[1]]

df.to_csv('cleaned_dataset.csv',index=False)
print('Analysis completed')
