# DecodeLabs Data Science Internship

## Week 1 - Advanced EDA & Feature Engineering

This project performs:
- Missing value treatment
- Outlier detection using IQR
- Feature engineering
- Exploratory Data Analysis

Tools: Python, Pandas, NumPy, Matplotlib, Scikit-learn
